Formatting your VLDB paper.
---------------------------

This file is readme!.txt

Morgan Kaufmann's formatting instructions for the VLDB Proceedings may
be found in the file format.txt. These guidelines must be adhered to
by the final version of your accepted paper.

In order to help you format your submissions, we have provided three
additional files, vldb.sty, vldb.cls, and vldb_format.doc.

vldb.sty is a LaTeX style file, defining environments which conform to
Morgan Kaufmann's guidelines. It should work with LaTeX versions 1 and 2. 
vldb.sty should be made to work by including it through a \documentstyle 
directive like this: \documentstyle[vldb]{article}. This style file
will insert the required copyright notice automatically.

vldb.cls is the adaptation of the vldb.sty file to the LaTeX2 class
format.  vldb.cls should be made to work by including it through a
direct \documentclass directive, like this: \documentclass{vldb}.

vldb_format.doc is a Word version of Morgan Kaufmann's guidelines,
appropriately formatted.

vldb_format.tex is a Latex2 version of vldb_format.doc (it uses the
vldb.cls class file).

You may, as you wish, use these style files in their entirety, or copy
out individual definitions or styles into your own document. However,
even if you use one of these files, the responsibility remains with
yourself to ensure that the final version of your paper meets the
guidelines as described in format.txt.

The copyright notice to be included in your paper is in the file
copyright_notice.txt.

The transfer of copyright form may be found in the file
copyright_form.txt. You should return a signed hard copy with the
final version of your paper.

For ease of downloading, copies of all of these files are included in
the archive all_files.zip.

All of these file (including this one) are available from:
http://www.dia.uniroma3.it/vldb2001/author_info/



Stefano Paraboschi
parabosc@elet.polimi.it
